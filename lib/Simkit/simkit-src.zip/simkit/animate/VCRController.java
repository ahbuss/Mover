package simkit.animate;

import simkit.SimEventSource;

/**
 * All VCRController instances must be able to respond to these actions
 * @version $Id: VCRController.java 1320 2012-10-30 16:16:43Z ahbuss $
 * @author  Arnold Buss
 */
public interface VCRController extends SimEventSource {
    
    public void start();
    
    public void stop();
    
    public void pause();
    
    public void rewind();
    
    public void step(); // 22 May 2004 - kas - added
    
    public void fastForward();
    
    public void setDeltaT(double deltaT);
    
    public void setMillisPerSimtime(double millisPerSimTime);

}

